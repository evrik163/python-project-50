from json import dumps


def json_formatter(lst):
    return dumps(lst)
