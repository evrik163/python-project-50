# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['logic', 'logic.parsers', 'logic.scripts']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'asciinema>=2.2.0,<3.0.0',
 'pytest-cov>=4.0.0,<5.0.0',
 'pytest>=7.2.0,<8.0.0']

entry_points = \
{'console_scripts': ['gendiff = logic.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/evrik163/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/evrik163/python-project-50/actions)\n[![Action badge](https://github.com/evrik163/python-project-50/actions/workflows/pipeline.yml/badge.svg)](https://github.com/evrik163/python-project-50/actions/workflows/pipeline.yml)\n[![Maintainability](https://api.codeclimate.com/v1/badges/89d5680c9b47b416b590/maintainability)](https://codeclimate.com/github/evrik163/python-project-50/maintainability)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/89d5680c9b47b416b590/test_coverage)](https://codeclimate.com/github/evrik163/python-project-50/test_coverage)\n# DESCRIPTION:\n\n**Вычислитель отличий**\n\nСкрипт на вход получает два файла формата YAML или JSON и затем выводит строку, показывающую разницу между ними.\n\n**Запуск справки:**\n\n`gendiff -h`\n\n**Запуск скрипта c настройками по-умолчанию:**\n\n`gendiff <file_path1> <file_path2>`\n\n**Сравнение JSON**\n\n[![asciicast](https://asciinema.org/a/fNw3BSLcBkiLd4hQM1zvBFj6s.svg)](https://asciinema.org/a/fNw3BSLcBkiLd4hQM1zvBFj6s)\n\n\n**Сравнение YAML**\n\n[![asciicast](https://asciinema.org/a/ANb1QP73jCB5wJVXledaedoP9.svg)](https://asciinema.org/a/ANb1QP73jCB5wJVXledaedoP9)\n\n\n**Рекурсивное сравнение**\n\n[![asciicast](https://asciinema.org/a/vqOJnObD6uZ9NfBFoncFYBjQE.svg)](https://asciinema.org/a/vqOJnObD6uZ9NfBFoncFYBjQE)\n',
    'author': 'evrik163',
    'author_email': 'evrik163@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0',
}


setup(**setup_kwargs)
